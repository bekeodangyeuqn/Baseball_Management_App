package com.example.baseballmanagementapp.Models;

import java.time.LocalDateTime;

public class Event {
    String name, eventId, location;
    LocalDateTime timeStart, timeEnd;

    public Event(String name, String eventId, String location, LocalDateTime timeStart, LocalDateTime timeEnd) {
        this.name = name;
        this.eventId = eventId;
        this.location = location;
        this.timeStart = timeStart;
        this.timeEnd = timeEnd;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public LocalDateTime getTimeStart() {
        return timeStart;
    }

    public void setTimeStart(LocalDateTime timeStart) {
        this.timeStart = timeStart;
    }

    public LocalDateTime getTimeEnd() {
        return timeEnd;
    }

    public void setTimeEnd(LocalDateTime timeEnd) {
        this.timeEnd = timeEnd;
    }
}
