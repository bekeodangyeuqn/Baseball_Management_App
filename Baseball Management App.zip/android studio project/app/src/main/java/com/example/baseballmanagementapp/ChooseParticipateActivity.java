package com.example.baseballmanagementapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.baseballmanagementapp.databinding.ActivityChooseParticipateBinding;

public class ChooseParticipateActivity extends AppCompatActivity {
    ActivityChooseParticipateBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityChooseParticipateBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.createTeamBtn.setClickable(true); // Enable click events
        binding.createTeamBtn.setFocusable(true); // Enable focus events
        binding.createTeamBtn.setOnClickListener(view -> {
            Intent intent = new Intent(ChooseParticipateActivity.this, CreateTeamActivity.class);
            startActivity(intent);
        });
    }
}