package com.example.baseballmanagementapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.baseballmanagementapp.databinding.ActivityCongrateCreateTeamBinding;
import com.example.baseballmanagementapp.databinding.ActivityCreateTeamBinding;

public class CongrateCreateTeamActivity extends AppCompatActivity {
    ActivityCongrateCreateTeamBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        binding = ActivityCongrateCreateTeamBinding.inflate(getLayoutInflater());
        super.onCreate(savedInstanceState);
        setContentView(binding.getRoot());
    }
}