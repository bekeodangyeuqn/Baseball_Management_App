package com.example.baseballmanagementapp.Models;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Practice extends Event{
    List<String> listOfExercise = new ArrayList<String>();

    public Practice(String name, String eventId, String location, LocalDateTime timeStart, LocalDateTime timeEnd, List<String> listOfExercise) {
        super(name, eventId, location, timeStart, timeEnd);
        this.listOfExercise = listOfExercise;
    }

    public List<String> getListOfExercise() {
        return listOfExercise;
    }

    public void setListOfExercise(List<String> listOfExercise) {
        this.listOfExercise = listOfExercise;
    }
}
