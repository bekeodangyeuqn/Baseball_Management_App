package com.example.baseballmanagementapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.baseballmanagementapp.databinding.ActivityCreateEventBinding;

public class CreateEventActivity extends AppCompatActivity {
    ActivityCreateEventBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        binding = ActivityCreateEventBinding.inflate(getLayoutInflater());
        super.onCreate(savedInstanceState);
        setContentView(binding.getRoot());
    }
}