package com.example.baseballmanagementapp.Models;

import java.time.LocalDateTime;

public class Game extends Event{
    Team yourTeam, oppTeam;

    public Game(String name, String eventId, String location, LocalDateTime timeStart, LocalDateTime timeEnd, Team yourTeam, Team oppTeam) {
        super(name, eventId, location, timeStart, timeEnd);
        yourTeam = this.yourTeam;
        oppTeam = this.oppTeam;
    }

    public Team getYourTeam() {
        return yourTeam;
    }

    public void setYourTeam(Team yourTeam) {
        this.yourTeam = yourTeam;
    }

    public Team getOppTeam() {
        return oppTeam;
    }

    public void setOppTeam(Team oppTeam) {
        this.oppTeam = oppTeam;
    }
}
